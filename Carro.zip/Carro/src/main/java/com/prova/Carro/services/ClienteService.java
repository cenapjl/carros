package com.prova.Carro.services;

import com.prova.Carro.domains.Cliente;
import com.prova.Carro.domains.dtos.ClienteDTO;
import com.prova.Carro.repositories.ClienteRepository;
import com.prova.Carro.services.exceptions.DataIntegrityViolationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ClienteService {

    @Autowired
    private ClienteRepository ClienteRepo;

    public List<ClienteDTO> findAll(){
        //retorna uma lista de ClienteDTO
        return ClienteRepo.findAll().stream().map(obj -> new ClienteDTO(obj)).
                collect(Collectors.toList());

    }
    public Cliente findbyId(int id){
        Optional<Cliente> obj = ClienteRepo.findById(id);
        return obj.orElse(null);
    }
    public Cliente findbyCpfC(String cpfC){
        Optional<Cliente> obj = ClienteRepo.findByCpfC(cpfC);
        return obj.orElse(null);
    }

    public Cliente create(ClienteDTO dto){
        dto.setIdCliente(null);
        Cliente obj = new Cliente(dto);
        return ClienteRepo.save(obj);
    }

    public Cliente update(Integer id, ClienteDTO objDto){
        objDto.setIdCliente(id);
        Cliente oldObj = findbyId(id);
        oldObj = new Cliente(objDto);
        return ClienteRepo.save(oldObj);
    }

    public void delete(Integer id){
        Cliente obj = findbyId(id);
        if (obj.getCarros().size()>0){
            throw new DataIntegrityViolationException("Cliente não pode ser deletado, pois tem um carro vinculado ");
        }
        ClienteRepo.deleteById(id);
    }

}

