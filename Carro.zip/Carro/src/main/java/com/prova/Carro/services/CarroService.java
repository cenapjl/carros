package com.prova.Carro.services;

import com.prova.Carro.domains.Carro;
import com.prova.Carro.domains.Cliente;
import com.prova.Carro.domains.Vendedor;
import com.prova.Carro.domains.dtos.CarroDTO;
import com.prova.Carro.repositories.CarroRepository;
import com.prova.Carro.repositories.ClienteRepository;
import com.prova.Carro.repositories.VendedorRepository;
import com.prova.Carro.services.exceptions.DataIntegrityViolationException;
import com.prova.Carro.services.exceptions.ObjectNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
@Service
public class CarroService {


    @Autowired
    private VendedorRepository vendedorRepo;

    @Autowired
    private ClienteRepository clienteRepo;

    @Autowired
    private CarroRepository carroRepo;


    public List<CarroDTO> findAll(){
        return carroRepo.findAll().stream().map(obj -> new CarroDTO(obj)).collect(Collectors.toList());
    }

    public Carro findbyId(Long id){
        Optional<Carro> obj = carroRepo.findById(id);
        return obj.orElseThrow(() -> new ObjectNotFoundException("Carro não encontrado Id:" + id));
    }

    public Carro findbyRenavan(String renavan){
        Optional<Carro> obj = carroRepo.findByRenavan(renavan);
        return obj.orElseThrow(() -> new  ObjectNotFoundException("Carro não encontrado Renavan:" + renavan));
    }

    public Carro create(CarroDTO dto){
        dto.setIdCarro(null);
        validaCarro(dto);
        Carro obj = new Carro(dto);
        return carroRepo.save(obj);
    }

    private void validaCarro(CarroDTO dto){
        Optional<Carro> obj = carroRepo.findByRenavan(dto.getRenavan());
        if(obj.isPresent() && obj.get().getIdCarro() != dto.getIdCarro()){
            throw new DataIntegrityViolationException("Renavan já cadastrado");
        }


        Optional<Vendedor> vendedor = vendedorRepo.findById(dto.getVendedor());
        if(!vendedor.isPresent()){
            throw new DataIntegrityViolationException("Vendedor - " + dto.getVendedor() + " não esta cadastrado");
        }

        Optional<Cliente> cliente = clienteRepo.findById(dto.getCliente());
        if(!cliente.isPresent()){
            throw new DataIntegrityViolationException("Cliente - " + dto.getCliente() + "não esta cadastrado");
        }
    }


    public Carro update(Long id, CarroDTO objDto){
        objDto.setIdCarro(id);
        Carro oldObj = findbyId(id);
        oldObj = new Carro(objDto);
        validaCarro(objDto);
        return  carroRepo.save(oldObj);
    }

    public void delete(Long id){
        Carro obj = findbyId(id);
        carroRepo.deleteById(id);
    }




}
