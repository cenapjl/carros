package com.prova.Carro.domains.enums;

public enum Tipo {

    SEDAN(1, "SEDAN"), SUV(2, "SUV"), HATACH(3, "HATACH"), PICKUP(4, "PICKUP"), ESPORTIVO(5, "ESPORTIVO");
    private Integer id;
    private String descricao;

    Tipo(Integer id,String descricao) {
        this.id = id;
        this.descricao = descricao;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public static Tipo toEnum(Integer id){
        if (id==null) return null;
        for (Tipo c : Tipo.values()){
            if (id.equals(c.getId())){
                return c;
            }
        }

        throw new IllegalArgumentException("Status do carro inválida");
    }
}

