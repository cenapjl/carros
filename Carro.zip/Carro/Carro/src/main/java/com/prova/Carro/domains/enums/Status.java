package com.prova.Carro.domains.enums;

public enum Status {

    DISPONIVEL(1, "DISPONIVEL"), VENDIDO(2, "VENDIDO"), EM_MANUTENCAO(3, "EM MANUTENCAO");
    private Integer id;
    private String descricao;

    Status(Integer id,String descricao) {
        this.id = id;
        this.descricao = descricao;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public static Status toEnum(Integer id){
        if (id==null) return null;
        for (Status c : Status.values()){
            if (id.equals(c.getId())){
                return c;
            }
        }

        throw new IllegalArgumentException("Status do carro inválida");
    }
}
