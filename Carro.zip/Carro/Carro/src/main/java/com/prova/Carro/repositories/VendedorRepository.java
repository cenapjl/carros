package com.prova.Carro.repositories;

public interface VendedorRepository {
}
