package com.prova.Carro.resources.exceptions;

public class ResourceExceptionHandler {
}
