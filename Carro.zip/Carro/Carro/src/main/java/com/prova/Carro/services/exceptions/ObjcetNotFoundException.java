package com.prova.Carro.services.exceptions;

public class ObjcetNotFoundException extends RuntimeException {
    public ObjcetNotFoundException(String message) {
        super(message);
    }
}
