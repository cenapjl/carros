package com.prova.Carro.domains;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.prova.Carro.domains.dtos.ClienteDTO;
import com.prova.Carro.domains.dtos.VendedorDTO;
import jakarta.persistence.*;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "cliente")
public class Cliente {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "seq_cliente")
    private Integer idCliente;

    @NotNull @NotBlank
    private String nomeC;

    @NotNull @NotBlank
    @Column(unique = true)
    private  String cpfC;

    @NotBlank @NotNull
    private String telefone;

    @NotNull @NotBlank
    private String estado;

    @NotNull @NotBlank
    private String cidade;

    @NotNull @NotBlank
    private String endereco;

    @JsonIgnore
    @OneToMany(mappedBy = "cliente")
    private List<Carro> carros = new ArrayList<>();

    public List<Carro> getCarros() {
        return carros;
    }

    public void setCarros(List<Carro> carros) {
        this.carros = carros;
    }

    public Cliente() {
    }

    public Cliente(Integer idCliente, String endereco, String cidade, String estado, String telefone, String cpfC, String nomeC) {
        this.idCliente = idCliente;
        this.endereco = endereco;
        this.cidade = cidade;
        this.estado = estado;
        this.telefone = telefone;
        this.cpfC = cpfC;
        this.nomeC = nomeC;
    }

    public Cliente(ClienteDTO dto){
        this.idCliente = dto.getIdCliente();
        this.nomeC = dto.getNomeC();
        this.cpfC = dto.getCpfC();
        this.telefone = dto.getTelefone();
        this.cidade = dto.getCidade();
        this.estado = dto.getEstado();
        this.endereco = dto.getEndereco();
    }

    public Integer getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(Integer idCliente) {
        this.idCliente = idCliente;
    }

    public @NotNull @NotBlank String getNomeC() {
        return nomeC;
    }

    public void setNomeC(@NotNull @NotBlank String nomeC) {
        this.nomeC = nomeC;
    }

    public @NotNull @NotBlank String getCpfC() {
        return cpfC;
    }

    public void setCpfC(@NotNull @NotBlank String cpfC) {
        this.cpfC = cpfC;
    }

    public @NotBlank @NotNull String getTelefone() {
        return telefone;
    }

    public void setTelefone(@NotBlank @NotNull String telefone) {
        this.telefone = telefone;
    }

    public @NotNull @NotBlank String getEstado() {
        return estado;
    }

    public void setEstado(@NotNull @NotBlank String estado) {
        this.estado = estado;
    }

    public @NotNull @NotBlank String getCidade() {
        return cidade;
    }

    public void setCidade(@NotNull @NotBlank String cidade) {
        this.cidade = cidade;
    }

    public @NotNull @NotBlank String getEndereco() {
        return endereco;
    }

    public void setEndereco(@NotNull @NotBlank String endereco) {
        this.endereco = endereco;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Cliente cliente = (Cliente) o;
        return Objects.equals(idCliente, cliente.idCliente) && Objects.equals(nomeC, cliente.nomeC) && Objects.equals(cpfC, cliente.cpfC) && Objects.equals(telefone, cliente.telefone) && Objects.equals(estado, cliente.estado) && Objects.equals(cidade, cliente.cidade) && Objects.equals(endereco, cliente.endereco);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCliente, nomeC, cpfC, telefone, estado, cidade, endereco);
    }
}

