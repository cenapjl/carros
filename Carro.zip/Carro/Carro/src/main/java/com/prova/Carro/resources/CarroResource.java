package com.prova.Carro.resources;

public class CarroResource {
}
