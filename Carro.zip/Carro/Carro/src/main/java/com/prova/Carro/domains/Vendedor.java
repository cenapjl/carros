package com.prova.Carro.domains;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.prova.Carro.domains.dtos.VendedorDTO;
import jakarta.persistence.*;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "vendedor")
public class Vendedor {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "seq_vendedor")
    private Integer idVendedor;

    @NotNull @NotBlank
    private String nomeV;

    @NotNull @NotBlank
    @Column(unique = true)
    private  String cpfV;

    @NotBlank @NotNull
    private String email;

    @NotNull @NotBlank
    private String cargo;

    @NotNull
    @Digits(integer = 15, fraction = 2)
    private BigDecimal salario;

    @JsonIgnore
    @OneToMany(mappedBy = "vendedor")
    private List<Carro> carros = new ArrayList<>();

    public List<Carro> getCarros() {
        return carros;
    }

    public void setCarros(List<Carro> carros) {
        this.carros = carros;
    }

    public Vendedor(){

    }

    public Vendedor(Integer idVendedor, String nomeV, String cpfV, String email, String cargo, BigDecimal salario) {
        this.idVendedor = idVendedor;
        this.nomeV = nomeV;
        this.cpfV = cpfV;
        this.email = email;
        this.cargo = cargo;
        this.salario = salario;
    }
    public Vendedor(VendedorDTO dto){
        this.idVendedor = dto.getIdVendedor();
        this.nomeV = dto.getNomeV();
        this.cpfV = dto.getCpfV();
        this.email = dto.getEmail();
        this.cargo = dto.getCargo();
        this.salario = dto.getSalario();
    }

    public Integer getIdVendedor() {
        return idVendedor;
    }

    public void setIdVendedor(Integer idVendedor) {
        this.idVendedor = idVendedor;
    }

    public @NotNull @NotBlank String getNomeV() {
        return nomeV;
    }

    public void setNomeV(@NotNull @NotBlank String nomeV) {
        this.nomeV = nomeV;
    }

    public @NotNull @NotBlank String getCpfV() {
        return cpfV;
    }

    public void setCpf(@NotNull @NotBlank String cpfV) {
        this.cpfV = cpfV;
    }

    public @NotBlank @NotNull String getEmail() {
        return email;
    }

    public void setEmail(@NotBlank @NotNull String email) {
        this.email = email;
    }

    public @NotNull @NotBlank String getCargo() {
        return cargo;
    }

    public void setCargo(@NotNull @NotBlank String cargo) {
        this.cargo = cargo;
    }

    public @NotNull @Digits(integer = 15, fraction = 2) BigDecimal getSalario() {
        return salario;
    }

    public void setSalario(@NotNull @Digits(integer = 15, fraction = 2) BigDecimal salario) {
        this.salario = salario;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Vendedor vendedor = (Vendedor) o;
        return Objects.equals(idVendedor, vendedor.idVendedor) && Objects.equals(nomeV, vendedor.nomeV) && Objects.equals(cpfV, vendedor.cpfV) && Objects.equals(email, vendedor.email) && Objects.equals(cargo, vendedor.cargo) && Objects.equals(salario, vendedor.salario) && Objects.equals(carros, vendedor.carros);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idVendedor, nomeV, cpfV, email, cargo, salario, carros);
    }
}
