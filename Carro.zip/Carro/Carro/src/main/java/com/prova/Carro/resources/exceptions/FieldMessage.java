package com.prova.Carro.resources.exceptions;

public class FieldMessage {
}
