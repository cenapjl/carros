package com.prova.Carro.domains.dtos;

import com.prova.Carro.domains.Vendedor;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;

public class VendedorDTO {

    private Integer idVendedor;

    @NotNull(message = "O campo Nome não pode ser nulo")
    @NotBlank(message = "O campo Nome não pode estar vazio ")
    private String nomeV;

    @NotNull(message = "O campo Cpf não pode ser nulo")
    @NotBlank(message = "O campo Cpf não pode estar vazio ")
    private String cpfV;

    @NotNull(message = "O campo Email não pode ser nulo")
    @NotBlank(message = "O campo Email não pode estar vazio ")
    private String email;

    @NotNull(message = "O campo Cargo não pode ser nulo")
    @NotBlank(message = "O campo Cargo não pode estar vazio ")
    private String cargo;

    @NotNull(message = "O campo Salario não pode ser nulo")
    @Digits(integer = 15, fraction = 2)
    private BigDecimal salario;

    public VendedorDTO() {
    }

    public VendedorDTO(Vendedor vendedor){
        this.idVendedor = vendedor.getIdVendedor();
        this.nomeV = vendedor.getNomeV();
        this.cpfV = vendedor.getCpfV();
        this.email = vendedor.getEmail();
        this.cargo = vendedor.getCargo();
        this.salario = vendedor.getSalario();
    }

    public Integer getIdVendedor() {
        return idVendedor;
    }

    public void setIdVendedor(Integer idVendedor) {
        this.idVendedor = idVendedor;
    }

    public @NotNull(message = "O campo Nome não pode ser nulo") @NotBlank(message = "O campo Nome não pode estar vazio ") String getNomeV() {
        return nomeV;
    }

    public void setNomeV(@NotNull(message = "O campo Nome não pode ser nulo") @NotBlank(message = "O campo Nome não pode estar vazio ") String nomeV) {
        this.nomeV = nomeV;
    }

    public @NotNull(message = "O campo Cpf não pode ser nulo") @NotBlank(message = "O campo Cpf não pode estar vazio ") String getCpfV() {
        return cpfV;
    }

    public void setCpfV(@NotNull(message = "O campo Cpf não pode ser nulo") @NotBlank(message = "O campo Cpf não pode estar vazio ") String cpfV) {
        this.cpfV = cpfV;
    }

    public @NotNull(message = "O campo Email não pode ser nulo") @NotBlank(message = "O campo Email não pode estar vazio ") String getEmail() {
        return email;
    }

    public void setEmail(@NotNull(message = "O campo Email não pode ser nulo") @NotBlank(message = "O campo Email não pode estar vazio ") String email) {
        this.email = email;
    }

    public @NotNull(message = "O campo Cargo não pode ser nulo") @NotBlank(message = "O campo Cargo não pode estar vazio ") String getCargo() {
        return cargo;
    }

    public void setCargo(@NotNull(message = "O campo Cargo não pode ser nulo") @NotBlank(message = "O campo Cargo não pode estar vazio ") String cargo) {
        this.cargo = cargo;
    }

    public @NotNull(message = "O campo Salario não pode ser nulo") @Digits(integer = 15, fraction = 2) BigDecimal getSalario() {
        return salario;
    }

    public void setSalario(@NotNull(message = "O campo Salario não pode ser nulo") @Digits(integer = 15, fraction = 2) BigDecimal salario) {
        this.salario = salario;
    }
}
