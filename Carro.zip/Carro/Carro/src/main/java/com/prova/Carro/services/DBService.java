package com.prova.Carro.services;

public class DBService {

}
