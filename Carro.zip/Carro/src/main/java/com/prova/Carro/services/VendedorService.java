package com.prova.Carro.services;

import com.prova.Carro.domains.Vendedor;
import com.prova.Carro.domains.dtos.VendedorDTO;
import com.prova.Carro.repositories.VendedorRepository;
import com.prova.Carro.services.exceptions.DataIntegrityViolationException;
import com.prova.Carro.services.exceptions.ObjectNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


@Service
public class VendedorService {

    @Autowired
    private VendedorRepository vendedorRepo;

    public List<VendedorDTO> findAll(){
        return vendedorRepo.findAll().stream().map(obj -> new VendedorDTO(obj)).collect(Collectors.toUnmodifiableList());
    }

    public Vendedor findbyId(int id){
        Optional<Vendedor> obj = vendedorRepo.findById(id);
        return obj.orElse(null);
    }

    public Vendedor findbyCpfV (String cpfV){
        Optional<Vendedor> obj = vendedorRepo.findByCpfV(cpfV);
        return obj.orElseThrow(() -> new ObjectNotFoundException("CPF não encontrado CPF:" + cpfV));
    }

    public  Vendedor create (VendedorDTO dto){
        dto.setIdVendedor(null);
        validaVendedorCpfV(dto);
        Vendedor obj = new Vendedor(dto);
        return vendedorRepo.save(obj);
    }

    private void validaVendedorCpfV(VendedorDTO dto){
        Optional<Vendedor> obj = vendedorRepo.findByCpfV(dto.getCpfV());
        if(obj.isPresent() && obj.get().getIdVendedor() != dto.getIdVendedor()){
            throw new DataIntegrityViolationException("Cpf já cadastrado");
        }
    }



    public  Vendedor update(Integer id, VendedorDTO objDto){
        objDto.setIdVendedor(id);
        Vendedor oldObj = findbyId(id);
        oldObj = new Vendedor(objDto);
        return  vendedorRepo.save(oldObj);
    }

    public void delete(Integer id){
        Vendedor obj = findbyId(id);
        if (obj.getCarros().size()>0){
            throw  new DataIntegrityViolationException("O vendedor não pode ser deletado, pois tem um carro vinculado nele");

        }
        vendedorRepo.deleteById(id);
    }




}

