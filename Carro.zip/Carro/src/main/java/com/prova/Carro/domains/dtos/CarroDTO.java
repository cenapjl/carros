package com.prova.Carro.domains.dtos;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.prova.Carro.domains.Carro;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.time.LocalDate;

public class CarroDTO {

    private Long idCarro;

    @NotNull(message = "O campo renavan não pode ser nulo")
    @NotBlank (message = "O campo renavan não pode estar vazio")
    private String renavan;

    @NotNull(message = "O campo modelo não pode ser nulo")
    @NotBlank (message = "O campo modelo não pode estar vazio")
    private String modelo;

    @NotNull(message = "O campo marca não pode ser nulo")
    @NotBlank (message = "O campo marca não pode estar vazio")
    private String marca;

    @NotNull(message = "O campo ano não pode ser nulo")
    @NotBlank (message = "O campo ano não pode estar vazio")
    private String ano;

    @NotNull(message = "O campo cor não pode ser nulo")
    @NotBlank (message = "O campo cor não pode estar vazio")
    private String cor;

    @NotNull(message = "O campo km não pode ser nulo")
    @NotBlank (message = "O campo km não pode estar vazio")
    private String km;

    @NotNull (message = "O campo preco não pode ser nulo")
    @Digits(integer = 15, fraction = 2)
    private BigDecimal preco;

    private int status;
    private int tipo;

    @NotNull(message = "O campo Cliente é requerido")
    private int Cliente;

    @NotNull(message = "O campo Vendedor é requerido")
    private int Vendedor;

    public CarroDTO() {
    }

    public CarroDTO(Carro carro) {
        this.idCarro = carro.getIdCarro();
        this.renavan = carro.getRenavan();
        this.modelo = carro.getModelo();
        this.marca = carro.getMarca();
        this.ano = carro.getAno();
        this.cor = carro.getCor();
        this.km = carro.getKm();
        this.preco = carro.getPreco();
        this.status = carro.getStatus().getId();
        this.tipo = carro.getTipo().getId();
        Cliente = carro.getCliente().getIdCliente();
        Vendedor = carro.getVendedor().getIdVendedor();
    }

    public Long getIdCarro() {
        return idCarro;
    }

    public void setIdCarro(Long idCarro) {
        this.idCarro = idCarro;
    }

    public @NotNull(message = "O campo renavan não pode ser nulo") @NotBlank(message = "O campo renavan não pode estar vazio") String getRenavan() {
        return renavan;
    }

    public void setRenavan(@NotNull(message = "O campo renavan não pode ser nulo") @NotBlank(message = "O campo renavan não pode estar vazio") String renavan) {
        this.renavan = renavan;
    }

    public @NotNull(message = "O campo modelo não pode ser nulo") @NotBlank(message = "O campo modelo não pode estar vazio") String getModelo() {
        return modelo;
    }

    public void setModelo(@NotNull(message = "O campo modelo não pode ser nulo") @NotBlank(message = "O campo modelo não pode estar vazio") String modelo) {
        this.modelo = modelo;
    }

    public @NotNull(message = "O campo marca não pode ser nulo") @NotBlank(message = "O campo marca não pode estar vazio") String getMarca() {
        return marca;
    }

    public void setMarca(@NotNull(message = "O campo marca não pode ser nulo") @NotBlank(message = "O campo marca não pode estar vazio") String marca) {
        this.marca = marca;
    }

    public @NotNull(message = "O campo ano não pode ser nulo") @NotBlank(message = "O campo ano não pode estar vazio") String getAno() {
        return ano;
    }

    public void setAno(@NotNull(message = "O campo ano não pode ser nulo") @NotBlank(message = "O campo ano não pode estar vazio") String ano) {
        this.ano = ano;
    }

    public @NotNull(message = "O campo cor não pode ser nulo") @NotBlank(message = "O campo cor não pode estar vazio") String getCor() {
        return cor;
    }

    public void setCor(@NotNull(message = "O campo cor não pode ser nulo") @NotBlank(message = "O campo cor não pode estar vazio") String cor) {
        this.cor = cor;
    }

    public @NotNull(message = "O campo km não pode ser nulo") @NotBlank(message = "O campo km não pode estar vazio") String getKm() {
        return km;
    }

    public void setKm(@NotNull(message = "O campo km não pode ser nulo") @NotBlank(message = "O campo km não pode estar vazio") String km) {
        this.km = km;
    }

    public @NotNull(message = "O campo preco não pode ser nulo") @Digits(integer = 15, fraction = 2) BigDecimal getPreco() {
        return preco;
    }

    public void setPreco(@NotNull(message = "O campo preco não pode ser nulo") @Digits(integer = 15, fraction = 2) BigDecimal preco) {
        this.preco = preco;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getTipo() {
        return tipo;
    }

    public void setTipo(int tipo) {
        this.tipo = tipo;
    }

    @NotNull(message = "O campo Cliente é requerido")
    public int getCliente() {
        return Cliente;
    }

    public void setCliente(@NotNull(message = "O campo Cliente é requerido") int cliente) {
        Cliente = cliente;
    }

    @NotNull(message = "O campo Vendedor é requerido")
    public int getVendedor() {
        return Vendedor;
    }

    public void setVendedor(@NotNull(message = "O campo Vendedor é requerido") int vendedor) {
        Vendedor = vendedor;
    }
}
