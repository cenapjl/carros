package com.prova.Carro.domains;


import com.prova.Carro.domains.dtos.CarroDTO;
import com.prova.Carro.domains.enums.Tipo;
import com.prova.Carro.domains.enums.Status;
import jakarta.persistence.*;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.util.Objects;


@Entity
@Table(name = "carro")
public class Carro {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_carro")
    private Long idCarro;

    @NotNull
    @Column(unique = true)
    private String renavan;

    @NotNull
    @Digits(integer = 15, fraction = 2)
    private BigDecimal preco;

    @NotNull @NotBlank
    private String modelo;

    @NotNull @NotBlank
    private String marca;

    @NotNull @NotBlank
    private String ano;

    @NotNull @NotBlank
    private String cor;

    @NotNull @NotBlank
    private String km;

    @Enumerated(EnumType.ORDINAL)
    @JoinColumn(name = "status")
    private Status status;

    @Enumerated(EnumType.ORDINAL)
    @JoinColumn(name = "tipo")
    private Tipo tipo;

    @ManyToOne
    @JoinColumn(name = "idcliente")
    private Cliente cliente;

    @ManyToOne
    @JoinColumn(name = "idvendedor")
    private Vendedor vendedor;

    public Carro() {
        this.preco = BigDecimal.ZERO;
        this.status = Status.DISPONIVEL;
        this.tipo = Tipo.SEDAN;
    }

    public Carro(Long idCarro, String renavan, BigDecimal preco, String modelo, String marca, String ano, String cor, String km, Status status, Tipo tipo, Cliente cliente, Vendedor vendedor) {
        this.idCarro = idCarro;
        this.renavan = renavan;
        this.preco = preco;
        this.modelo = modelo;
        this.marca = marca;
        this.ano = ano;
        this.cor = cor;
        this.km = km;
        this.status = status;
        this.tipo = tipo;
        this.cliente = cliente;
        this.vendedor = vendedor;
    }

    public Carro(CarroDTO dto){
        this.idCarro = dto.getIdCarro();
        this.renavan = dto.getRenavan();
        this.preco = dto.getPreco();
        this.modelo = dto.getModelo();
        this.marca = dto.getMarca();
        this.ano = dto.getAno();
        this.cor = dto.getCor();
        this.km = dto.getKm();

        this.cliente = new Cliente();
        this.cliente.setIdCliente(dto.getCliente());
        this.vendedor = new Vendedor();
        this.vendedor.setIdVendedor(dto.getVendedor());

        this.status  = Status.toEnum(dto.getStatus());
        this.tipo = Tipo.toEnum(dto.getTipo());
    }

    public Long getIdCarro() {
        return idCarro;
    }

    public void setIdCarro(Long idCarro) {
        this.idCarro = idCarro;
    }

    public @NotNull String getRenavan() {
        return renavan;
    }

    public void setRenavan(@NotNull String renavan) {
        this.renavan = renavan;
    }

    public @NotNull @Digits(integer = 15, fraction = 2) BigDecimal getPreco() {
        return preco;
    }

    public void setPreco(@NotNull @Digits(integer = 15, fraction = 2) BigDecimal preco) {
        this.preco = preco;
    }

    public @NotNull @NotBlank String getModelo() {
        return modelo;
    }

    public void setModelo(@NotNull @NotBlank String modelo) {
        this.modelo = modelo;
    }

    public @NotNull @NotBlank String getMarca() {
        return marca;
    }

    public void setMarca(@NotNull @NotBlank String marca) {
        this.marca = marca;
    }

    public @NotNull @NotBlank String getAno() {
        return ano;
    }

    public void setAno(@NotNull @NotBlank String ano) {
        this.ano = ano;
    }

    public @NotNull @NotBlank String getCor() {
        return cor;
    }

    public void setCor(@NotNull @NotBlank String cor) {
        this.cor = cor;
    }

    public @NotNull @NotBlank String getKm() {
        return km;
    }

    public void setKm(@NotNull @NotBlank String km) {
        this.km = km;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public Tipo getTipo() {
        return tipo;
    }

    public void setTipo(Tipo tipo) {
        this.tipo = tipo;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Vendedor getVendedor() {
        return vendedor;
    }

    public void setVendedor(Vendedor vendedor) {
        this.vendedor = vendedor;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Carro carro = (Carro) o;
        return Objects.equals(idCarro, carro.idCarro) && Objects.equals(renavan, carro.renavan) && Objects.equals(preco, carro.preco) && Objects.equals(modelo, carro.modelo) && Objects.equals(marca, carro.marca) && Objects.equals(ano, carro.ano) && Objects.equals(cor, carro.cor) && Objects.equals(km, carro.km) && status == carro.status && tipo == carro.tipo && Objects.equals(cliente, carro.cliente) && Objects.equals(vendedor, carro.vendedor);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCarro, renavan, preco, modelo, marca, ano, cor, km, status, tipo, cliente, vendedor);
    }
}
