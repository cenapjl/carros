package com.prova.Carro.services;

import com.prova.Carro.domains.Carro;
import com.prova.Carro.domains.Cliente;
import com.prova.Carro.domains.Vendedor;
import com.prova.Carro.domains.enums.Status;
import com.prova.Carro.domains.enums.Tipo;
import com.prova.Carro.repositories.CarroRepository;
import com.prova.Carro.repositories.ClienteRepository;
import com.prova.Carro.repositories.VendedorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
public class DBService {

@Autowired
    private VendedorRepository vendedorRepository;

@Autowired
    private ClienteRepository clienteRepository;

@Autowired
    private CarroRepository carroRepository;

public void initDB(){
    Vendedor vendedor1 = new Vendedor(null, "Ronan", "1234567", "ronan123@gmail.com.br", "Gerente",new BigDecimal("120").setScale(2) );
    Cliente cliente1 = new Cliente(null, "Rua:São Carlos 47","Fernandopolis" ,"SP","17997898989", "1231231231", "Cena");
    Carro carro1 = new Carro(null, "132456852", new BigDecimal("120000").setScale(2),"Viagem", "BMW", "2000", "Preta", "19999", Status.DISPONIVEL, Tipo.ESPORTIVO, cliente1, vendedor1);

vendedorRepository.save(vendedor1);
clienteRepository.save(cliente1);
carroRepository.save(carro1);


}







}
