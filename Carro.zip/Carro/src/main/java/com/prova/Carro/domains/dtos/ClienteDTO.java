package com.prova.Carro.domains.dtos;

import com.prova.Carro.domains.Cliente;
import jakarta.persistence.Column;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;


public class ClienteDTO {

    private Integer idCliente;

    @NotNull(message = "O campo Nome não pode ser nulo")
    @NotBlank(message = "O campo Nome não pode estar vazio ")
    private String nomeC;

    @NotNull(message = "O campo cpf não pode ser nulo")
    @NotBlank(message = "O campo cpf não pode estar vazio ")
    @Column(unique = true)
    private  String cpfC;

    @NotNull(message = "O campo telefone não pode ser nulo")
    @NotBlank(message = "O campo telefone não pode estar vazio ")
    private String telefone;

    @NotNull(message = "O campo estado não pode ser nulo")
    @NotBlank(message = "O campo estado não pode estar vazio ")
    private String estado;

    @NotNull(message = "O campo cidade não pode ser nulo")
    @NotBlank(message = "O campo cidade não pode estar vazio ")
    private String cidade;

    @NotNull(message = "O campo endereco não pode ser nulo")
    @NotBlank(message = "O campo endereco não pode estar vazio ")
    private String endereco;

    public ClienteDTO() {
    }

    public ClienteDTO(Cliente cliente) {
        this.idCliente = cliente.getIdCliente();
        this.nomeC = cliente.getNomeC();
        this.cpfC = cliente.getCpfC();
        this.telefone = cliente.getTelefone();
        this.estado = cliente.getEstado();
        this.cidade = cliente.getCidade();
        this.endereco = cliente.getEndereco();
    }

    public Integer getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(Integer idCliente) {
        this.idCliente = idCliente;
    }

    public @NotNull(message = "O campo Nome não pode ser nulo") @NotBlank(message = "O campo Nome não pode estar vazio ") String getNomeC() {
        return nomeC;
    }

    public void setNomeC(@NotNull(message = "O campo Nome não pode ser nulo") @NotBlank(message = "O campo Nome não pode estar vazio ") String nomeC) {
        this.nomeC = nomeC;
    }

    public @NotNull(message = "O campo cpf não pode ser nulo") @NotBlank(message = "O campo cpf não pode estar vazio ") String getCpfC() {
        return cpfC;
    }

    public void setCpfC(@NotNull(message = "O campo cpf não pode ser nulo") @NotBlank(message = "O campo cpf não pode estar vazio ") String cpfC) {
        this.cpfC = cpfC;
    }

    public @NotNull(message = "O campo telefone não pode ser nulo") @NotBlank(message = "O campo telefone não pode estar vazio ") String getTelefone() {
        return telefone;
    }

    public void setTelefone(@NotNull(message = "O campo telefone não pode ser nulo") @NotBlank(message = "O campo telefone não pode estar vazio ") String telefone) {
        this.telefone = telefone;
    }

    public @NotNull(message = "O campo estado não pode ser nulo") @NotBlank(message = "O campo estado não pode estar vazio ") String getEstado() {
        return estado;
    }

    public void setEstado(@NotNull(message = "O campo estado não pode ser nulo") @NotBlank(message = "O campo estado não pode estar vazio ") String estado) {
        this.estado = estado;
    }

    public @NotNull(message = "O campo cidade não pode ser nulo") @NotBlank(message = "O campo cidade não pode estar vazio ") String getCidade() {
        return cidade;
    }

    public void setCidade(@NotNull(message = "O campo cidade não pode ser nulo") @NotBlank(message = "O campo cidade não pode estar vazio ") String cidade) {
        this.cidade = cidade;
    }

    public @NotNull(message = "O campo endereco não pode ser nulo") @NotBlank(message = "O campo endereco não pode estar vazio ") String getEndereco() {
        return endereco;
    }

    public void setEndereco(@NotNull(message = "O campo endereco não pode ser nulo") @NotBlank(message = "O campo endereco não pode estar vazio ") String endereco) {
        this.endereco = endereco;
    }
}
