package com.prova.Carro.repositories;

import com.prova.Carro.domains.Vendedor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface VendedorRepository extends JpaRepository<Vendedor, Integer> {


    Optional<Vendedor> findByCpfV(String cpfV);




}

